---
name: Feature request
about: Suggest an idea for DevTropolis
title: "[Feature] "
labels: enhancement
assignees: ''
---

**Is your feature request related to a problem?**
A clear description of what the problem is, if any.

**Describe the solution you'd like**
What you want to happen.

**Describe alternatives you've considered**
Any alternative solutions or features you've considered.

**Additional context**
Mockups, references to similar features elsewhere, etc.
