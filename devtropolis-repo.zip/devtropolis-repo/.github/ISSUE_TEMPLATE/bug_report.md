---
name: Bug report
about: Report something that isn't working
title: "[Bug] "
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of what's wrong.

**Steps to reproduce**
1. Go to '...'
2. Enter username '...'
3. Click '...'
4. See error

**Expected behavior**
What you expected to happen.

**Screenshots**
If applicable, add screenshots to help explain the problem.

**Environment**
- Browser + version: [e.g. Chrome 125]
- OS: [e.g. Android 14, macOS 15]
- Device: [e.g. desktop, iPhone 15]

**GitHub username tested (if relevant)**
e.g. `torvalds`

**Additional context**
Anything else that might help.
